# -*- coding:utf-8 -*-
# Copyright (c) 2020 Huawei Technologies Co.,Ltd.
#
# openGauss is licensed under Mulan PSL v2.
# You can use this software according to the terms
# and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS,
# WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# ----------------------------------------------------------------------------

import subprocess
from gspylib.inspection.common import SharedFuncs
from gspylib.inspection.common.CheckItem import BaseItem
from gspylib.inspection.common.CheckResult import ResultStatus
from base_utils.os.file_util import FileUtil


class CheckUsedPort(BaseItem):
    def __init__(self):
        super(CheckUsedPort, self).__init__(self.__class__.__name__)

    def getPortRange(self):
        portRangeValue = \
            FileUtil.readFile('/proc/sys/net/ipv4/ip_local_port_range')[0]
        (startPort, endPort) = portRangeValue.split()
        portRange = int(endPort) - int(startPort)

        return portRange

    def getTcpUsedPort(self):
        if (self.ipAddr):
            serviceIP = self.ipAddr
        else:
            serviceIP = SharedFuncs.getIpByHostName(self.host)

        cmd = "netstat -ano|awk '{print $4}'|grep '%s'|sort|uniq -c|" \
              "grep ' 1 '|wc -l" % serviceIP
        tcpUsed = SharedFuncs.runShellCmd(cmd)

        return int(tcpUsed)

    def doCheck(self):
        portRange = self.getPortRange()
        tcpUsed = self.getTcpUsedPort()
        defaultPortRange = 60000 - 32768
        if (portRange < defaultPortRange):
            self.result.rst = ResultStatus.WARNING
            self.result.val = "port range is %s,Check items are not passed." \
                              % portRange
            return

        if (tcpUsed > portRange * 0.8):
            self.result.rst = ResultStatus.WARNING
            self.result.val = "tcp port used is %s,Check items are" \
                              " not passed." % tcpUsed
            return

        self.result.rst = ResultStatus.OK
        self.result.val = "port range is %s,tcp port used is %s," \
                          "Check items pass." % (portRange, tcpUsed)
        return
